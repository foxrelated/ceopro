<?php

return array(
  array(
    'title' => 'Switch Skins',
    'description' => 'Allow users switch skin.',
    'category' => 'Core',
    'type' => 'widget',
    
    'name' => 'yntheme.switch-skins',
  ),)
?>