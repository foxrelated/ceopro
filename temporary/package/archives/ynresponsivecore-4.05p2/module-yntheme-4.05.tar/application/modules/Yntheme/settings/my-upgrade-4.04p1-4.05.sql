UPDATE `engine4_core_modules` SET `version` = '4.04p2' where 'name' = 'yntheme';
UPDATE `engine4_core_menuitems` SET `enabled` = '0' where 'name' = 'core_admin_main_plugins_yntheme';